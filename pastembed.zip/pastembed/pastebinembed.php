<?php
/*
Plugin Name: PasteBinEmbed
Plugin URI: http://cico.click/wordpress-pastebin-com-plugin-simple-embed-code
Description: This is the simple plugin for wordpress, with this plugin you can embed snippets code from http://pastebin.com . Easy to use , just paste url from http://pastebin.com and thats it.
Version: 1.1
Author: cico.click
Author URI: http://cico.click
*/

/*  Copyright 2011  Cico Zeljko  (email : cico.zeljko@gmail.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Pastebin embed
 */
function pastebin_embed_handler( $find_id, $attr, $url, $rawcode ) {

    $http_schema   = is_ssl() ? 'https' : 'http';
    $pastebin_id   = esc_attr( $find_id[1]);
    $embed_code = '<br><script src="' . $http_schema . '://pastebin.com/embed_js/' . $pastebin_id . '"></script><br>';

    return apply_filters( 'embed_pastebin', $embed_code, $find_id, $attr, $url, $rawcode );

}
function pastebin_embed() {

    wp_embed_register_handler(
        'pastebin',
        '#https://pastebin.com/(.*)#i',
        'pastebin_embed_handler'
    );

}
add_action( 'init', 'pastebin_embed' );

